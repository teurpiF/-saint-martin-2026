# Saint-Martin 2026

Mini-site statique humoristique avec un compte à rebours caché derrière un bouton.

## Aperçu local

Ouvrir `index.html` dans un navigateur. Garder `cochon-saint-martin.svg` dans le même dossier.

## Publication gratuite sur GitHub Pages

1. Créer un dépôt public nommé `saint-martin-2026` sur GitHub, dans le compte `teurpiF`.
2. Ajouter `index.html`, `cochon-saint-martin.svg` et `README.md` à la racine du dépôt.
3. Dans **Settings → Pages**, choisir **Deploy from a branch**, puis la branche `main` et le dossier `/(root)`.
4. Enregistrer. Le site sera publié à l'adresse `https://teurpif.github.io/saint-martin-2026/` après le déploiement.

## Modifier date et heure

Dans `index.html`, la date cible est définie par :
`new Date('2026-11-21T12:40:00+01:00')`

Cette heure utilise le fuseau de Paris (CET, UTC+1) au 21 novembre 2026.
